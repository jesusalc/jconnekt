<?php
/**
* @author		Arunoda Susiripala
* @package		jconnect
* @subpackage	elgg
* @copyright	Arunoda Susiripala
* @license 		http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*/

JCFactory::load_js_library();

echo "<div id='jconnekt_login_box'></div>";
echo "<script type='text/javascript'>jconnekt.draw_login('jconnekt_login_box')</script>";
echo "<br>";




