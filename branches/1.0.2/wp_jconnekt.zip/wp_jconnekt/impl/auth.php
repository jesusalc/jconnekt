<?php
/**
* @author		Arunoda Susiripala
* @package		jconnect
* @subpackage	elgg
* @copyright	Arunoda Susiripala
* @license 		http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*/

class JCElggAuth extends JCAuth{

	public function login($status,$data){
		//$data['username'],$data['email'],$data['user_group']
		
	}

	public function logout(){
	
	}
}