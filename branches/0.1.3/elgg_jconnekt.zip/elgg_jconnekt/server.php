<?php
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");
require_once($CONFIG->pluginspath . "elgg_jconnekt/jconnekt_api/server.php");