Elgg JConnect Plugin...
-------------------------------------
This is a Plugin which made elgg as an external Application for JConnect


How to Install
-------------------------
01.Create a directory named elgg_jconnect in mod directory in elgg...
02.Copy all the content here into that directory..
03.Goto Administration section of Elgg
04.Goto Tool Administration
05.Find the Plugin named elgg_jconnect and enable it...
06.Now there should be a menu link in the left hand side call JConnect Config..
07.Click On that
08.If You a Configuration Window for JConnect Installtion Succeeded.

How To Configure It
---------------------------------
01.Click JConnect Config in the Administartion Section
02.Use the Information provide there to make a connection to JConnect(in Joomla)
03.Get the Secret Key You Generate from JConnect and Put it in the Secret Key TextBox in this Window
04.Click Update Button.
05.Go to JConnect and Goto the corresponding ExApp click sendInfo
06.Then again click the JConnect Config...
07.If Succeeded all the text boxes should be filled with some information (send by JConnect)
08.Now You are done.