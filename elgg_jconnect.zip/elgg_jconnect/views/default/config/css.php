<?php
/**
* @author		Arunoda Susiripala
* @package		jconnect
* @subpackage	elgg
* @copyright	Arunoda Susiripala
* @license 		http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU Public License version 2
*/
?>
.jconnectContainer {
	padding: 10px;
	background-color: #dedede;
	-webkit-border-radius: 8px; 
	-moz-border-radius: 8px;
}